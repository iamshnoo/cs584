from setuptools import setup

setup(
    name="hw1",
    version="1.0",
    description="CS 584 Fall 2022 Homework 1 Anjishnu Mukherjee G01373990",
    author="Anjishnu Mukherjee",
    author_email="amukher6@gmu.edu",
)
